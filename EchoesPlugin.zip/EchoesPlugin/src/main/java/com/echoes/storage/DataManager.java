package com.echoes.storage;

import org.bukkit.configuration.file.*;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class DataManager {

    public final Map<String, UUID> owners = new HashMap<>();
    public final Map<UUID, String> oaths = new HashMap<>();

    private final File file;
    private final FileConfiguration cfg;

    public DataManager(JavaPlugin plugin) {
        file = new File(plugin.getDataFolder(), "data.yml");
        cfg = YamlConfiguration.loadConfiguration(file);
    }

    public void load() {
        if (!cfg.contains("empires")) return;

        cfg.getConfigurationSection("empires").getKeys(false).forEach(name ->
            owners.put(name, UUID.fromString(cfg.getString("empires."+name)))
        );

        if (cfg.contains("oaths"))
            cfg.getConfigurationSection("oaths").getKeys(false).forEach(u ->
                oaths.put(UUID.fromString(u), cfg.getString("oaths."+u))
            );
    }

    public void save() {
        cfg.set("empires", null);
        cfg.set("oaths", null);

        owners.forEach((k,v) -> cfg.set("empires."+k, v.toString()));
        oaths.forEach((k,v) -> cfg.set("oaths."+k, v));

        try { cfg.save(file); } catch (IOException ignored) {}
    }
}